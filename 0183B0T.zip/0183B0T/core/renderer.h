#pragma once

bool InstallRendererHooks();